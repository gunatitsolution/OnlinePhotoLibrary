//
//  constants.swift
//  photoLibrary
//
//  Created by Elluminati iTunesConnect on 19/07/18.
//  Copyright © 2018 aaa. All rights reserved.
//

import Foundation
import UIKit

let  APPDELEGATE = UIApplication.shared.delegate as! AppDelegate

struct WebServices
{
    static let  WS_GET_PHOTOS = "http://pastebin.com/raw/wgkJgazE"
}
