//
//  photosCollectionItemLikes.swift
//  photoLibrary
//
//  Created by Elluminati iTunesConnect on 21/07/18.
//  Copyright © 2018 aaa. All rights reserved.
//

import Foundation
class checkListItem {
    //var text = ""
    var checked = false
    
    func toggledChecked(){
        checked = !checked
    }
}
