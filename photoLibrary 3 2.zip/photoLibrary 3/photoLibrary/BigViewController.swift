//
//  BigViewController.swift
//  photoLibrary
//
//  Created by Nirav on 21/07/18.
//  Copyright © 2018 aaa. All rights reserved.
//

import UIKit

class BigViewController: UIViewController {

    @IBOutlet weak var imgview: UIImageView!
    var urls : String = ""
    var nameOfimage : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        //        let url = URL(string: str)
        let urlt = URL.init(string: urls)
        downloadImage(url: urlt as! URL)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func saveTodisk(_ sender: Any) {
        self.saveImageToDocumentDirectory(imgview.image! , filename: nameOfimage)
    }
    func saveImageToDocumentDirectory(_ chosenImage: UIImage , filename : String) -> String {
        let directoryPath =  NSHomeDirectory().appending("/Documents/")
        if !FileManager.default.fileExists(atPath: directoryPath) {
            do {
                try FileManager.default.createDirectory(at: NSURL.fileURL(withPath: directoryPath), withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error)
            }
        }
        //        let dateFormate = DateFormatter()
        //        dateFormate.dateFormat = "MM/dd/yyyy"
        //        let date = NSDate()
        //        let stringOfDate = dateFormate.string(from: date as Date)
        //        print(stringOfDate)
        //        let filename = stringOfDate.appending(".jpg")
        
        let filepath = directoryPath.appending(filename)
        let url = NSURL.fileURL(withPath: filepath)
        // print(filename)
        print(filepath)
        do {
            try UIImageJPEGRepresentation(chosenImage, 1.0)?.write(to: url, options: .atomic)
            return String.init("/Documents/\(filename)")
        } catch {
            print(error)
            print("file cant not be save at path \(filepath), with error : \(error)");
            return filepath
        }
    }
    func downloadImage(url: URL){
        print("Download Started")
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() {
                self.imgview.image = UIImage(data: data)
            }
        }
    }
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
}
