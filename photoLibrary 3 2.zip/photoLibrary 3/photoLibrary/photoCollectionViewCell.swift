//
//  photoCollectionViewCell.swift
//  photoLibrary
//
//  Created by Elluminati iTunesConnect on 19/07/18.
//  Copyright © 2018 aaa. All rights reserved.
//

import UIKit

class photoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var btnDownload: UIButton!
    
    @IBOutlet weak var likesAnimate: UIImageView!
    @IBOutlet weak var btnLike: UIButton!
}
