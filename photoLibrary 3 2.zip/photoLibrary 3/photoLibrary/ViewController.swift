//
//  ViewController.swift
//  photoLibrary
//
//  Created by Elluminati iTunesConnect on 19/07/18.
//  Copyright © 2018 aaa. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var customCollectionView: UICollectionView!
    var customColletionPhotos = [String]()
    var oldCustomCollectionPhotos = [String]()
    var CustomCollectionPhotosLikes = [String]()
    var checkMarkItems = [checkListItem]()
    
    let sectionInsets = UIEdgeInsets(top: 15.0, left: 10.0, bottom: 15.0, right: 10.0)
    let itemsPerRow : CGFloat = 2
    override func viewDidLoad() {
        super.viewDidLoad()
        GotPhotsFromApi()
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(doSomething), for: .valueChanged)
        
        // this is the replacement of implementing: "collectionView.addSubview(refreshControl)"
        customCollectionView.refreshControl = refreshControl
        
        // customCollectionView.reloadData()
        customCollectionView.dataSource = self
        customCollectionView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: Actions
    @IBAction func btnGetPhots(_ sender: Any) {
        // GotPhotsFromApi()
        // print(customColletionPhotos)
        
    }
    
    
    @IBAction func btnsClick(_ sender: Any) {
        var indexPath:IndexPath? = nil
        indexPath = self.customCollectionView.indexPathForView(view: sender as AnyObject)
        print("index path : \(indexPath?.row)")
        if (sender as! UIButton).tag == 2 {
            print("download")
            
            if let cell = customCollectionView.cellForItem(at: indexPath!) as? photoCollectionViewCell {
                if let imagePhoto = cell.imgView.image {
                    print(saveImageToDocumentDirectory(imagePhoto,filename: cell.imgView.restorationIdentifier!))
                }
            }
            
        }else if (sender as! UIButton).tag == 3 {
            if let cell = customCollectionView.cellForItem(at: indexPath!) as? photoCollectionViewCell {
//                if CustomCollectionPhotosLikes[(indexPath?.row)!] == "like" {
//                    cell.btnLike.setImage(UIImage(named: "unlike"), for: .normal)
//                    CustomCollectionPhotosLikes[(indexPath?.row)!] = "unlike"
//                }else{
//                    cell.btnLike.setImage(UIImage(named: "like"), for: .normal)
//                    CustomCollectionPhotosLikes[(indexPath?.row)!] = "like"
//                }
                let item = checkMarkItems[(indexPath?.row)!]
                item.toggledChecked()
                configureCheckmark(for: cell, with: item)
            }
        }
        
    }
    
    //MARK: Webservice Call(API) Functions
    func GotPhotsFromApi(){
        let urlStr = WebServices.WS_GET_PHOTOS
        var url = URL(string: urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        print(url!)
        self.customColletionPhotos.removeAll()
        self.CustomCollectionPhotosLikes.removeAll()
        self.checkMarkItems.removeAll()
        Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON
            { (response:DataResponse<Any>) in
                let jsonDecoder = JSONDecoder()
                var responseModel = try? jsonDecoder.decode([Json4Swift_Base].self , from: response.data!)
                print(responseModel)
                if let responseModel = responseModel {
                    if responseModel.count > 0 {
                        for i in 0..<responseModel.count {
                            print("START DATA - \(i)")
                            let result = responseModel[i]
                            //                            print(result.user?.id)
                            //                            print(result.user?.username)
                            //                            print(result.user?.name)
                            //                            print(result.user?.profile_image?.small)
                            //                            print(result.user?.profile_image?.medium)
                            //                            print(result.user?.profile_image?.large)
                            //                            print("END DATA - \(i)")
                            print(result.links?.download)
                            if let image = result.links?.download{
                                self.customColletionPhotos.append(image)
                                self.CustomCollectionPhotosLikes.append("unlike")
                            }
                        }
                        print(self.customColletionPhotos)
                        self.customCollectionView.reloadData()
                    }
                }
        }
        
        
        //        Alamofire.request(url!, method: .get, parameters: ["":""], encoding: URLEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
        //
        //            switch(response.result) {
        //            case .success(_):
        //                if let data = response.result.value{
        //                   // print(response.result.value)
        //                    let results = response.result.value as! [[String:Any]]
        //                    for i in 0...results.count {
        //                        print("////////////Start - results[\(i)]////////////")
        //                        for (key,value) in results[i]{
        //                            print("key:\(key) value:\(value)")
        //                        }
        //                        print("////////////End - results[\(i)]//////////////")
        //                    }
        //                }
        //                break
        //
        //            case .failure(_):
        //                print(response.result.error)
        //                break
        //
        //            }
        //        }
        
    }
    
    //MARK: DELEGATES - CollectionView
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        for _ in 0..<customColletionPhotos.count{
            let row0item = checkListItem()
            row0item.checked = false
            checkMarkItems.append(row0item)
        }
        return customColletionPhotos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let uicCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellReuseIdentifier", for: indexPath) as! photoCollectionViewCell
        
        
        //        var activityIndicator = UIActivityIndicatorView()
        //        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
        //        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        //        let transform: CGAffineTransform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        //        activityIndicator.transform = transform
        //        activityIndicator.center = self.view.center
        //        activityIndicator.startAnimating()
        //        self.view.addSubview(activityIndicator)
        //
        
        
        
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        //        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        //        let transform: CGAffineTransform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        //        activityIndicator.transform = transform
        activityIndicator.center = uicCell.imgView.center
        uicCell.imgView.addSubview(activityIndicator)
        uicCell.imgView.bringSubview(toFront: activityIndicator)
        // activityIndicator.frame = uicCell.imgView.bounds
        activityIndicator.startAnimating()
        
        
        //        let activityView = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        
        //        activityView.center = uicCell.imgView.center
        //        // Also tried
        //        activityView.center = uicCell.contentView.center
        //        activityView.startAnimating()
        
        //   uicCell.imgView.image = UIImage(named:"\(customColletionPhotos[indexPath.row])")
        
        let str = customColletionPhotos[indexPath.row]
        uicCell.likesAnimate.isHidden = true
        if let url = URL(string: str) {
            print("Download Started")
            getDataFromUrl(url: url) { data, response, error in
                guard let data = data, error == nil else { return }
                print(response?.suggestedFilename ?? url.lastPathComponent)
                print("Download Finished")
                DispatchQueue.main.async() {
                    uicCell.imgView.image = UIImage(data: data)
                    uicCell.imgView.restorationIdentifier = response?.suggestedFilename ?? "tmo.jpg"
                    if uicCell.imgView != nil{
                        activityIndicator.stopAnimating()
                    }
                }
            }
        }
        let item = checkMarkItems[indexPath.row]
        
        configureCheckmark(for: uicCell, with: item)
        
        return uicCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5) {
            if let cell = collectionView.cellForItem(at: indexPath) as? photoCollectionViewCell {
                cell.imgView.transform = .init(scaleX: 0.95, y: 0.95)
                cell.contentView.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5) {
            if let cell = collectionView.cellForItem(at: indexPath) as? photoCollectionViewCell {
                cell.imgView.transform = .identity
                cell.contentView.backgroundColor = .clear
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //print(customColletionPhotos[indexPath.row])
//
//        if let cell = collectionView.cellForItem(at: indexPath) as? photoCollectionViewCell {
//            let imageData = UIImagePNGRepresentation(cell.imgView.image!)
//            let docDir = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
//            let imageURL = docDir.appendingPathComponent("tmp.png")
//            try! imageData?.write(to: imageURL)
//        }
        //
        //        if let cell = collectionView.cellForItem(at: indexPath) as? photoCollectionViewCell
        //        {
        //            let strLink = customColletionPhotos[indexPath.row]
        //            cell.imgView.downloadedFrom(link: strLink)
        //
        //        }
        
        
//        if let cell = collectionView.cellForItem(at: indexPath) as? photoCollectionViewCell {
//            if let imagePhoto = cell.imgView.image {
//                print(saveImageToDocumentDirectory(imagePhoto,filename: cell.imgView.restorationIdentifier!))
//            }
//        }
        if let cell = customCollectionView.cellForItem(at: indexPath) as? photoCollectionViewCell {
            
            
            let imgdownload : BigViewController = self.storyboard?.instantiateViewController(withIdentifier: "big")as! BigViewController
            
            
            imgdownload.urls = customColletionPhotos[indexPath.row]
            imgdownload.nameOfimage = cell.imgView.restorationIdentifier! 
            self.navigationController?.pushViewController(imgdownload, animated: true)
            // print(saveImageToDocumentDirectory(imagePhoto,filename: cell.imgView.restorationIdentifier!))
            
        }
        
//        let imgdownload : BigViewController = self.storyboard?.instantiateViewController(withIdentifier: "big")as! BigViewController
//
//
//        imgdownload.urls = customColletionPhotos[indexPath.row]
//        imgdownload.nameOfimage =
//
//        self.navigationController?.pushViewController(imgdownload, animated: true)
//
    }
    
    //MARK: USER DEINED FUNCTIONS
    
    func configureCheckmark(for cell: photoCollectionViewCell, with item: checkListItem){
        if item.checked {
          
                cell.likesAnimate.isHidden = false
                cell.likesAnimate.alpha = 1.0
                
                UIView.animate(withDuration: 1.0, delay: 1.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    
                    cell.likesAnimate?.alpha = 0
                    
                }, completion: {
                    (value:Bool) in
                    
                    cell.likesAnimate?.isHidden = true
                })
                
            
            cell.btnLike.setImage(UIImage(named: "like"), for: .normal)
        } else {
            cell.btnLike.setImage(UIImage(named: "unlike"), for: .normal)
        }
    }
    
    @objc func doSomething(refreshControl: UIRefreshControl) {
        print("Hello World!")
        GotPhotsFromApi()
        // somewhere in your code you might need to call:
        refreshControl.endRefreshing()
    }
    
    func downloadImage(url: URL){
        //        print("Download Started")
        //        getDataFromUrl(url: url) { data, response, error in
        //            guard let data = data, error == nil else { return }
        //            print(response?.suggestedFilename ?? url.lastPathComponent)
        //            print("Download Finished")
        //            DispatchQueue.main.async() {
        //                self.imageView.image = UIImage(data: data)
        //            }
        //        }
    }
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
 
    func saveImageToDocumentDirectory(_ chosenImage: UIImage , filename : String) -> String {
        let directoryPath =  NSHomeDirectory().appending("/Documents/")
        if !FileManager.default.fileExists(atPath: directoryPath) {
            do {
                try FileManager.default.createDirectory(at: NSURL.fileURL(withPath: directoryPath), withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error)
            }
        }
//        let dateFormate = DateFormatter()
//        dateFormate.dateFormat = "MM/dd/yyyy"
//        let date = NSDate()
//        let stringOfDate = dateFormate.string(from: date as Date)
//        print(stringOfDate)
//        let filename = stringOfDate.appending(".jpg")
        
        let filepath = directoryPath.appending(filename)
        let url = NSURL.fileURL(withPath: filepath)
       // print(filename)
        print(filepath)
        do {
            try UIImageJPEGRepresentation(chosenImage, 1.0)?.write(to: url, options: .atomic)
            return String.init("/Documents/\(filename)")
        } catch {
            print(error)
            print("file cant not be save at path \(filepath), with error : \(error)");
            return filepath
        }
    }
}

//MARK: EXTENSION

extension ViewController : UICollectionViewDelegateFlowLayout {
    //1
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        //2
        let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
        let availableWidth = view.frame.width - paddingSpace
        let widthPerItem = availableWidth / itemsPerRow
        
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
    
    //3
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    // 4
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
    
}

extension UICollectionView {
    func indexPathForView(view: AnyObject) -> IndexPath? {
        let originInCollectioView = self.convert(CGPoint.zero, from: (view as! UIView))
        return self.indexPathForItem(at: originInCollectioView) as IndexPath?
    }
}

//extension UIImageView {
//    func downloadedFrom(url: URL, contentMode mode: UIViewContentMode = .scaleAspectFit) {
//        contentMode = mode
//        URLSession.shared.dataTask(with: url) { data, response, error in
//            guard
//                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
//                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
//                let data = data, error == nil,
//                let image = UIImage(data: data)
//                else { return }
//            DispatchQueue.main.async() {
//                self.image = image
//            }
//            }.resume()
//    }
//    func downloadedFrom(link: String, contentMode mode: UIViewContentMode = .scaleAspectFit) {
//        guard let url = URL(string: link) else { return }
//        downloadedFrom(url: url, contentMode: mode)
//    }
//}
